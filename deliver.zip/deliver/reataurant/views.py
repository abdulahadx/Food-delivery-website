from lib2to3.pgen2.token import SLASH
from django.shortcuts import render
from django.views import View

class Dashboard(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'reataurant/dashboard.html')